% Define the set
S = [-4,4,3,-3,-2,-1,0,1,2];

% Generate all 8D combinations using ndgrid
[X1, X2, X3, X4, X5, X6, X7, X8] = ndgrid(S, S, S, S, S, S, S, S);

% Reshape each to a column vector and stack as rows
Z = [X1(:), X2(:), X3(:), X4(:), X5(:), X6(:), X7(:), X8(:)];

% Z is now a 390625 x 8 matrix, where each row is one possible z vector
  % returns [390625, 8]
Z=Z';
  
N = 8;              % Full DFT size (8x8)
M = 3;              % Desired number of rows

% Generate the full 8x8 DFT matrix (unnormalized)
F = exp(-2j * pi * (0:N-1)' * (0:N-1) / N);

% Randomly select M unique row indices from 1 to N
selected_rows = randperm(N, M);

% Extract those rows to form the partial DFT matrix A (4x8)
A = F(selected_rows, :);

Y = A * Z;

tol = 1e-10;  % numerical tolerance

% Extract real and imaginary parts
Y_real = round(real(Y), 10);   % 4 x 390625
Y_imag = round(imag(Y), 10);   % 4 x 390625

% Transpose for row-wise sorting
Y_real_T = Y_real.';  % 390625 x 4

% Sort real part lexicographically
[Y_real_sorted, sort_idx] = sortrows(Y_real_T);

% Get sorted imag part accordingly
Y_imag_sorted = Y_imag(:, sort_idx).';

% Compare adjacent real rows
real_diffs = abs(diff(Y_real_sorted, 1, 1));  % 390624 x 4
real_max_diff = max(real_diffs, [], 2);

% Candidate duplicate indices (where real parts match closely)
real_match_idx = find(real_max_diff <= tol);

% Now confirm matches using imag part
fprintf('\n✅ Filtering based on real part, checking imaginary...\n');

count = 0;
for i = 1:min(5, numel(real_match_idx))  % limit display
    idx1 = real_match_idx(i);
    idx2 = idx1 + 1;

    % Get the imaginary vectors for these candidates
    imag_vec1 = Y_imag_sorted(idx1, :);
    imag_vec2 = Y_imag_sorted(idx2, :);

    % Check if imaginary parts also match within tolerance
    if max(abs(imag_vec1 - imag_vec2)) <= tol
        count = count + 1;
        orig_idx1 = sort_idx(idx1);
        orig_idx2 = sort_idx(idx2);

        fprintf('\n⚠️ Duplicate %d found:\n', count);
        fprintf('Original column indices: %d and %d\n', orig_idx1, orig_idx2);
        fprintf('Y(:, %d):\n', orig_idx1);
        disp(Y(:, orig_idx1));
        fprintf('Y(:, %d):\n', orig_idx2);
        disp(Y(:, orig_idx2));
    end
end

if count == 0
    fprintf('\n✅ No duplicate columns found in Y within given tolerance.\n');
else
    fprintf('\n⚠️ Total %d duplicate pairs found (real + imag match).\n', count);
end

