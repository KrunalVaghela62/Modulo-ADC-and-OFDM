%% Setup
S = [1,2,3];
a_true = [0;3;0;1;0;0;3;0];
N = 8;
lambda = 1;
h = [2  1 -1 5 0 0 0 0]';
holes_location = [1,3,5,6,8];

% Precompute matrices
D = dftmtx(N)/sqrt(N);
D_h = D';
A = generate_all_as(S, holes_location, N);
circ_h_all = genrate_all_circh(A, h);
flam_all = genrate_all_flam(circ_h_all, lambda);
Z_all = genrate_all_Z(circ_h_all, flam_all);

% Noise parameters
sigma_values = 0.5:0.1:2;
numRealizations = 500;

% Store results
mean_error_z = zeros(size(sigma_values));
var_error_z  = zeros(size(sigma_values));
mean_error_a = zeros(size(sigma_values));
var_error_a  = zeros(size(sigma_values));

% Non-hole indices
not_holes_idx = setdiff(1:N, holes_location);

%% Loop over noise levels
for s_idx = 1:length(sigma_values)
    sigma = sigma_values(s_idx);
    sigma = sqrt(sigma);
    error_z_vals = zeros(numRealizations,1);
    error_a_vals = zeros(numRealizations,1);
    
    for r = 1:numRealizations
        %% Generate noisy f_lam
        f_lam_clean = generate_f_lam(N, lambda, a_true, h);
        f_lam_noisy = f_lam_clean + sigma*randn(N,1);
        
        % Measurement
        y = D_h * f_lam_noisy;
        y(not_holes_idx) = [];
        D_h_reduced = D_h;
        D_h_reduced(not_holes_idx,:) = [];
        
        %% ---- z-based estimate ----
        error_min = Inf;
        for idx = 1:size(Z_all,2)
            y_est = D_h_reduced * Z_all(:,idx);
            err = norm(y_est - y)^2;
            if err < error_min
                error_min = err;
                bestEstimate_z = Z_all(:, idx);
                bestEstimate_a_z = A(:, idx);
            end
        end
        
        %% ---- f_lam-based estimate ----
        error_min = Inf;
        for idx = 1:size(flam_all,2)
            err = norm(flam_all(:,idx) - f_lam_noisy)^2;
            if err < error_min
                error_min = err;
                bestEstimate_flam = flam_all(:, idx);
                bestEstimate_a_f = A(:, idx);
            end
        end
        
        %% ---- Classification error (0-1 loss) ----
        error_z_vals(r) = sum(a_true ~= bestEstimate_a_z) / N;
        error_a_vals(r) = sum(a_true ~= bestEstimate_a_f) / N;
    end
    
    % Compute mean and variance across realizations
    mean_error_z(s_idx) = mean(error_z_vals);
    var_error_z(s_idx)  = var(error_z_vals);
    
    mean_error_a(s_idx) = mean(error_a_vals);
    var_error_a(s_idx)  = var(error_a_vals);
end

%% Plot results (with translucent shaded variance)
figure; hold on;
alphaVal = 0.3; % transparency level

% Shaded variance for z-based estimator (light blue)
fill([sigma_values fliplr(sigma_values)], ...
    [mean_error_z - sqrt(var_error_z), fliplr(mean_error_z + sqrt(var_error_z))], ...
    [0.2 0.5 1], 'EdgeColor','none', 'FaceAlpha', alphaVal);

% Shaded variance for a-based estimator (light red)
fill([sigma_values fliplr(sigma_values)], ...
    [mean_error_a - sqrt(var_error_a), fliplr(mean_error_a + sqrt(var_error_a))], ...
    [1 0.3 0.3], 'EdgeColor','none', 'FaceAlpha', alphaVal);

% Mean error lines
plot(sigma_values, mean_error_z, 'b-o', 'LineWidth',2, 'MarkerFaceColor','b');
plot(sigma_values, mean_error_a, 'r-s', 'LineWidth',2, 'MarkerFaceColor','r');

xlabel('\sigma (Noise Std)');
ylabel('Mean Classification Error');
title('Classification Error vs Noise Level (\sigma)');
legend('z-based variance','a-based variance','z-based mean','a-based mean', ...
       'Location','northwest');

grid on;
box on;
set(gca, 'FontSize', 12);
hold off;
