function f_lam_est=f_lam_est(S,N)
D=dftmtx(N);
[X1, X2, X3, X4, X5, X6, X7, X8] = ndgrid(S, S, S, S, S, S, S, S);

% Reshape each to a column vector and stack as rows
A = [X1(:), X2(:), X3(:), X4(:), X5(:), X6(:), X7(:), X8(:)];

% A is now a 390625 x 8 matrix, where each row is one possible z vector
  % returns [390625, 8]
A=A';
size(A);
end