function A=generate_all_as(S,holes_location,N)
    vecs = cell(1, N);
    for i = 1:N
        if ismember(i, holes_location)
            vecs{i} = 0;
        else
            vecs{i} = S;
        end
    end
    A = combvec(vecs{:});

end