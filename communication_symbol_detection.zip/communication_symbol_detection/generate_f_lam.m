function f_lam=generate_f_lam(N,lambda,a,h)
D=dftmtx(N);
D = D/sqrt(N);
F_a=D*a;
y = cconv(F_a, h, N);
y_real = real(y);
y_imag = imag(y);
mod_y_real = y_real - (2*lambda)*floor((y_real+lambda)/(2*lambda));
mod_y_imag = y_imag - (2*lambda)*floor((y_imag+lambda)/(2*lambda));

f_lam=mod_y_real+1j*mod_y_imag;

end
