function Z = genrate_all_Z(circ_h,flam)
    Z = flam - circ_h;
end