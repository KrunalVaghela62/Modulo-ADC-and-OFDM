function circ_h=genrate_all_circh(A,h)
    N=size(A,1);
    D = dftmtx(N);
    D = D/sqrt(N);
    h = h';
    for idx=1:size(A,2)
        circ_h(:,idx)=cconv(D*A(:,idx),h,N);
    end
end