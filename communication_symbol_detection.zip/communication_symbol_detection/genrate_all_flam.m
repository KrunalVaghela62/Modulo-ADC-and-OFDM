function flam=genrate_all_flam(circ_h,lambda)
    for idx=1:size(circ_h,2)
        y = circ_h(:,idx);
        y_real = real(y);
        y_imag = imag(y);
        mod_y_real = y_real - (2*lambda)*floor((y_real+lambda)/(2*lambda));
        mod_y_imag = y_imag - (2*lambda)*floor((y_imag+lambda)/(2*lambda));
        flam(:,idx) = mod_y_real + 1j*mod_y_imag;
    end
end