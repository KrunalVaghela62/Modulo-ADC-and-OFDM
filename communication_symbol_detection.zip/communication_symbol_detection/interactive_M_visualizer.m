S = [1,2,3];
N = 8;
h = [2  1 -1 5 0 0 0 0]';
tol = 1e-10; % Tolerance for column comparison
result_summary = cell(N,1);
not_holes_loc_cell = cell(N,1);

for M = 1:N
    num_not_holes = N - M;
    if num_not_holes < 0
        break;
    end
    if num_not_holes == 0
        not_hole_combs = zeros(1,0);
    else
        not_hole_combs = nchoosek(1:N, num_not_holes);
    end
    numCombs = size(not_hole_combs, 1);
    success_rates = zeros(numCombs,1);
    for c = 1:numCombs
        not_holes_location = not_hole_combs(c,:);
        holes_location = setdiff(1:N, not_holes_location);

        % -- pipeline --
        a_all = generate_all_as(S, holes_location, N);
        circ_h = genrate_all_circh(a_all,h);
        flam = genrate_all_flam(circ_h, 1);
        Z_all = genrate_all_Z(circ_h, flam);
        A = dftmtx(N)/sqrt(N);
        A = A';
        if ~isempty(not_holes_location)
            A(not_holes_location,:) = [];
        end
        M_actual = size(A,1);
        Y = A * Z_all;

        % -- tolerance-based uniqueness check --
        numCols = size(Y,2);
        isUnique = true(1, numCols);
        for j = 1:numCols
            if ~isUnique(j)
                continue;
            end
            for k = j+1:numCols
                if isUnique(k) && norm(Y(:,j)-Y(:,k)) < tol
                    isUnique(j) = false;
                    isUnique(k) = false;
                end
            end
        end

        numUniqueCols = sum(isUnique);
        success_rates(c) = (numUniqueCols/(3^(N-M_actual))) * 100;
    end
    result_summary{M} = success_rates;
    not_holes_loc_cell{M} = not_hole_combs;

    % -- plot histogram and enable click callback --
    figure;
    b = bar(success_rates, 'FaceColor',[0.2 0.6 0.9]);
    xlabel(['Combination index (Total = ' num2str(numCombs) ')']);
    ylabel('Success Percentage (%)');
    title(['Histogram of Success Rates for M = ' num2str(M) ...
        ' holes (' num2str(N-M) ' not-holes)']);
    grid on;
    b.UserData.M = M;
    b.UserData.not_holes_loc_cell = not_hole_combs;
    b.UserData.success_rates = success_rates;
    set(b, 'ButtonDownFcn', @barClickCallback);
end
disp('✅ Completed all combinations for each M');

function barClickCallback(src, event)
    ax = ancestor(src, 'axes');
    clickPoint = ax.CurrentPoint(1,1);
    [~, idx] = min(abs((1:length(src.YData)) - clickPoint));
    M = src.UserData.M;
    locs = src.UserData.not_holes_loc_cell(idx,:);
    rate = src.UserData.success_rates(idx);
    fprintf('👉 For M = %d, Bar #%d clicked\n', M, idx);
    fprintf('   Success rate = %.2f%%\n', rate);
    fprintf('   Removed rows (not_holes_location) = [%s]\n\n', num2str(locs));
end
% --------- Summary plot: Success Rate vs M ---------
means = zeros(N,1);
variances = zeros(N,1);

for M = 1:N
    rates = result_summary{M};     % Vector of success rates for each combination at this M
    means(M) = mean(rates);
    variances(M) = var(rates);
end

Ms = 1:N;
upper = means + sqrt(variances);   % Shaded region uses 1 standard deviation above/below mean
lower = means - sqrt(variances);

figure;
hold on;
fill([Ms fliplr(Ms)], [upper' fliplr(lower')], [0.8 0.91 1.0], 'EdgeColor','none', 'FaceAlpha', 0.5); % Light blue shade
plot(Ms, means, 'b-', 'LineWidth', 2);
plot(Ms, upper, 'b--', Ms, lower, 'b--'); % Upper/lower lines (optional)
xlabel('Number of Holes (M)');
ylabel('Mean Success Rate (%)');
title('Mean Success Rate vs. Number of Holes (M)');
grid on;
legend('1 Std Dev Range','Mean Success Rate','Location','best');
hold off;

%{
% --- Your success rates for each M ---
success_data = {
    [12.3914,1.4175,6.5844,0.1829,6.7215,1.4632,11.8427,0.0914],  % M=1
    [62.4143,8.0933,54.0466,51.9890,11.2483,51.9890,7.9561,53.7723,2.8807,52.5377,...
     62.6886,1.3717,53.9095,11.2483,54.4582,8.5048,62.4143,7.9561,52.5377,6.5844,...
     62.5514,48.4225,8.6420,38.6831,0.1372,38.2716,8.6420,47.7366], % M=2
    [51.0288,98.3539,53.9095,98.3539,49.7942,2.8807,46.0905,53.9095,98.3539,50.6173,...
     54.7325,51.0288,49.3827,98.3539,3.7037,98.3539,49.7942,51.0288,46.0905,98.3539,...
     68.3128,6.5844,49.3827,52.6749,98.3539,53.0864,6.5844,51.0288,2.8807,53.0864,...
     68.3128,52.6749,49.7942,98.3539,51.0288,92.5926,37.8601,87.6543,50.2058,9.8765,...
     50.2058,36.2140,87.6543,45.6790,48.5597,94.2387,3.7037,87.6543,9.8765,87.6543,...
     39.9177,93.4156,34.5679,51.0288,35.3909,93.4156], % M=3
    [97.5309,87.6543,97.5309,58.0247,100,76.5432,97.5309,97.5309,87.6543,77.7778,...
     87.6543,71.6049,100,87.6543,100,77.7778,100,75.3086,100,80.2469,3.7037,87.6543,...
     75.3086,97.5309,58.0247,79.0123,80.2469,77.7778,100,97.5309,97.5309,80.2469,...
     76.5432,87.6543,97.5309,77.7778,100,80.2469,100,81.4815,77.7778,95.0617,76.5432,...
     100,61.7284,56.7901,77.7778,75.3086,100,9.8765,100,83.9506,75.3086,95.0617,100,...
     92.5926,56.7901,83.9506,56.7901,100,77.7778,56.7901,77.7778,75.3086,80.2469,...
     92.5926,56.7901,81.4815,100,77.7778], % M=4
    [100,77.7778,81.4815,74.0741,100,100,100,51.8519,100,14.8148,100,81.4815,100,...
     100,92.5926,81.4815,51.8519,81.4815,100,92.5926,100,100,85.1852,100,70.3704,...
     100,77.7778,100,100,100,70.3704,85.1852,77.7778,100,100,100,85.1852,100,62.9630,...
     100,85.1852,3.7037,85.1852,62.9630,100,70.3704,77.7778,85.1852,70.3704,100,100,...
     100,85.1852,77.7778,85.1852,100], % M=5
    [100,77.7778,100,22.2222,100,77.7778,100,100,100,55.5556,100,100,100,100,44.4444,...
     100,0,100,33.3333,100,100,100,33.3333,44.4444,55.5556,100,100,100], % M=6
    [0,100,33.3333,100,0,100,33.3333,100], % M=7
    [100] % M=8
};

% --- Compute mean and variance ---
numM = numel(success_data);
mean_success = zeros(numM,1);
std_success = zeros(numM,1);

for i = 1:numM
    mean_success(i) = mean(success_data{i});
    std_success(i) = std(success_data{i});
end

% --- Plot Mean ± Std (Shaded) ---
M = 1:numM;
figure;
hold on;
fill([M, fliplr(M)], ...
     [mean_success - std_success; flipud(mean_success + std_success)]', ...
     [0.85 0.9 1], 'EdgeColor', 'none'); % shaded std region
plot(M, mean_success, 'o-', 'LineWidth', 2, 'Color', [0 0.45 0.75], 'MarkerFaceColor', [0 0.45 0.75]);
hold off;

xlabel('M (number of available measurements)');
ylabel('Average Success %');
title('Summary: Success Rate vs M');
grid on;
xlim([1 numM]);
ylim([0 110]);
%}