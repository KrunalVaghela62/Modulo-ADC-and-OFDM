S=[-2,0,2];
p=[0.2,0.6,0.2];
N=8;
lambda=1;
cnt = 0;
h = [0.8  1 -1 0.6];
%%leaving here check where y=Az fails .. find from this examples
a=[2     2    -2     0     0     0    -2    -2]

f_lam = generate_f_lam(N,lambda,a,h);

sigma=sqrt(0.2);
%f_lam_noisy=f_lam+ sigma*randn(N,1);
%noise = f_lam_noisy-f_lam
%f_lam=f_lam_noisy;
%f_lam=awgn(f_lam,15);
a_est=exhaustive_search_f_lam(S, N, lambda, f_lam, h);
a_est=a_est'
D=dftmtx(N);
F_a=D*a';
y = cconv(F_a', h, N);
y=y';
circ_a=y
z_estimate=z_exhaust(S,N ,lambda, f_lam, h,a)
D=dftmtx(N);
D_h=D'/N;
y = D_h*f_lam;
z_D= D_h*z_estimate;
h = [0.8  1 -1 0.6 0 0 0 0];
rec=y-z_D;
d_h=D_h*h';
a_rec_real=[];
a_rec_imag=[];
for idx=1:N
    
    a_rec_real(idx,1)=(real(rec(idx))/real(d_h(idx)))/8;
    a_rec_imag(idx,1)=(imag(rec(idx))/imag(d_h(idx)));
end
a_rec_real'


combs = combvec(S, S, S, S, S, S, S, S)';  % 6561 x 8

%% Compute Euclidean distance from v to every combination
diffs = combs - a_rec_real';                   % 6561 x 8
distances = sqrt(sum(diffs.^2, 2));  % 6561 x 1

%% Find the closest vector
[~, min_idx] = min(distances);
closest_vec = combs(min_idx, :)

%{
for i=1:1
h = [0.8  1 -1 0.6];
f_lam = generate_f_lam(N,lambda,combs(:,i)',h);
%f_lam = awgn(f_lam,snr);
exhaustive_search_f_lam(S, N, lambda, f_lam, h);
z_estimate=z_exhaust(S,N ,lambda, f_lam, h,combs(:,i)');
D=dftmtx(N);
F_a=D*combs(:,i);
circ_a = cconv(F_a', h, N);
circ_a=circ_a';
z_true = f_lam-circ_a;
diff = z_true - z_estimate;


if all(abs(diff) < 1e-10)
    cnt = cnt + 1;
    fprintf('success');
else
    disp(combs(:,i)');
    fprintf('fail');
end

end

cnt
%}



%{
D=dftmtx(N);
D_h=D';
y = D_h*f_lam;
z_D= D_h*z_estimate;
h = [0.8  1 -1 0.6 0 0 0 0];
rec=y-z_D;
d_h=D*h';
a_rec_real=[];
a_rec_imag=[];
for idx=1:N
    
    a_rec_real(idx,1)=(real(rec(idx))/real(d_h(idx)))/8;
    a_rec_imag(idx,1)=(imag(rec(idx))/imag(d_h(idx)))/8;
end


a_rec_real
a_rec_imag
%}