S = [1,2,3];
N = 12;

result_summary = cell(N,1);         % Store success results per M
not_holes_loc_cell = cell(N,1);     % Store combinations of removed rows

% ---- Step 1: Compute success rates for all combinations ----
for M = 1:N
    num_not_holes = N - M;
    if num_not_holes < 0
        break;
    end

    if num_not_holes == 0
        not_hole_combs = zeros(1,0);
    else
        not_hole_combs = nchoosek(1:N, num_not_holes);
    end

    numCombs = size(not_hole_combs, 1);
    success_rates = zeros(numCombs,1);

    for c = 1:numCombs
        not_holes_location = not_hole_combs(c,:);
        holes_location = setdiff(1:N, not_holes_location);

        % ---- your pipeline ----
        a_all = generate_all_as(S, holes_location, N);
        circ_h = genrate_all_circh(a_all);
        flam = genrate_all_flam(circ_h, 1);
        Z_all = genrate_all_Z(circ_h, flam);

        A = dftmtx(N)/sqrt(N);
        if ~isempty(not_holes_location)
            A(not_holes_location,:) = [];
        end

        M_actual = size(A,1);
        Y = A * Z_all;

        [uniqueCols, ~, ic] = unique(Y', 'rows');
        counts = histcounts(ic, 1:max(ic)+1);
        uniqueOnly = uniqueCols(counts == 1, :)';
        numUniqueCols = size(uniqueOnly, 2);

        success_rates(c) = (numUniqueCols / ((length(S))^(N - M_actual))) * 100;
    end

    result_summary{M} = success_rates;
    not_holes_loc_cell{M} = not_hole_combs;
end

% ---- Step 2: Compute mean and std for each M ----
mean_success = zeros(N,1);
std_success = zeros(N,1);

for M = 1:N
    mean_success(M) = mean(result_summary{M});
    std_success(M) = std(result_summary{M});
end

% ---- Step 3: Plot Success Rate vs M with shaded variance ----
figure;
hold on;

% shaded region = mean ± std
fill([1:N, fliplr(1:N)], ...
     [mean_success - std_success; flipud(mean_success + std_success)]', ...
     [0.8 0.9 1], 'EdgeColor', 'none');

% plot mean success
plot(1:N, mean_success, 'o-', 'LineWidth', 2, 'MarkerFaceColor', [0 0.45 0.75]);

xlabel('M (number of available measurements)');
ylabel('Average Success %');
title('Summary: Success Rate vs M with Variance');
grid on;
xlim([1 N]);
ylim([0 105]);

hold off;
