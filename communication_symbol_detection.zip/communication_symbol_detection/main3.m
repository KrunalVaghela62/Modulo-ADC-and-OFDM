S = [1,2,3];
a_true=[0
   3
   0
   1
   0
   0
   3
   0]
N=8;
lambda=1;
D = dftmtx(N);
D = D/sqrt(N);
h = [2  1 -1 5 0 0 0 0];
h = h';
D_h=D';
holes_location=[1,3,5,6,8];
A=generate_all_as(S,holes_location,N);
f_lam = generate_f_lam(N,lambda,a_true,h);
sigma=sqrt(1.6);
f_lam=f_lam+ sigma*randn(N,1);
circ_h=cconv(D*a_true,h,N);
z_true=f_lam-circ_h;
circ_h_all=genrate_all_circh(A,h);
flam_all=genrate_all_flam(circ_h_all,lambda);
Z_all= genrate_all_Z(circ_h_all,flam_all);
y_all=D_h*flam_all;
size(y_all)
y_all([2,4,7], :) = [];

%%NOW WHAT WE HAVE IS f_lam

D_h = D';

y = D_h*f_lam;
y([2,4,7]) = [];
D_h([2,4,7], :) = []; 
error=Inf;
for idx=1:size(Z_all,2)
    y_estimated = D_h*Z_all(:,idx);
    if((norm(y_estimated-y))^2<error)
        error=(norm(y_estimated-y))^2;
        bestEstimate_z = Z_all(:, idx);
        bestEstimate_a = A(:, idx); 
    end
end
bestEstimate_a
error=Inf;
for idx=1:size(flam_all,2)
    if((norm(flam_all(:,idx)-f_lam))^2<error)
        error=(norm(flam_all(:,idx)-f_lam))^2;
        bestEstimate_flam = flam_all(:, idx);
        newestimate_a=A(:,idx);
    end
end
newestimate_a

minDist=Inf;
for i = 1:size(y_all,2)
    for j = i+1:size(y_all,2)
        d = norm(y_all(:,i) - y_all(:,j));   % works for complex entries
        if d < minDist
            minDist = d;
            closestCols = [i j];
        end
    end
end

fprintf('Minimum distance for y_s= %.6f between columns %d and %d\n', ...
        minDist, closestCols(1), closestCols(2));
minDist=Inf;
for i = 1:size(flam_all,2)
    for j = i+1:size(flam_all,2)
        d = norm(flam_all(:,i) - flam_all(:,j));   % works for complex entries
        if d < minDist
            minDist = d;
            closestCols = [i j];
        end
    end
end

fprintf('Minimum distance for flam_all= %.6f between columns %d and %d\n', ...
        minDist, closestCols(1), closestCols(2));