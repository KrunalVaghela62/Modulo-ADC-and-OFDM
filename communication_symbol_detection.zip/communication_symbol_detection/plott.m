% Values from your results
m = 12:-1:1; % Measurements
numUniqueCols = [509100, 171242, 58585, 18820, 6394, 2159, 729, 243, 45, 2, 9, 1];
totalComb = 3.^m;

percent_unique = (numUniqueCols ./ totalComb) * 100;

% Plot
figure;
bar(m, percent_unique, 'FaceColor', [0.2 0.5 0.8]);
xlabel('Number of measurements (m)');
ylabel('Percent unique columns (%)');
title('Percent of unique columns vs. measurements (N=12)');
grid on;
set(gca, 'xtick', m, 'XDir','reverse');
