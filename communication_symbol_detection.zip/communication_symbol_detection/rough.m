S = [1,2,3];
N = 8;
h = [2  1 -1 5 0 0 0 0]';
not_hole_locs_cell = {
    [], ...
    [2], ...
    [4,7], ...
    [2,5,7], ...
    [2,4,6,7], ...
    [2,4,5,6,8], ...
    [1,2,4,5,7,8], ...
    [1,2,3,4,6,7,8] ...
};
hole_locs_cell = cell(size(not_hole_locs_cell));
for k = 1:length(not_hole_locs_cell)
    nh = not_hole_locs_cell{k};
    hole_locs_cell{k} = setdiff(1:N, nh);  % Indices of holes
end

tol = 1e-10; % Tolerance for considering two columns as the same
result_table = [];

for i = 1:length(hole_locs_cell)
    holes_location = hole_locs_cell{i};
    a_all = generate_all_as(S, holes_location, N);
    circ_h = genrate_all_circh(a_all,h);
    flam = genrate_all_flam(circ_h, 1);
    Z_all = genrate_all_Z(circ_h, flam);
    A = dftmtx(N);
    A = A/sqrt(N);
    A = A'; % Hermitian
    not_holes_location = not_hole_locs_cell{i};

    if ~isempty(not_holes_location)
        A(not_holes_location, :) = [];
    end
    M = size(A,1);

    Y = A * Z_all;
    numCols = size(Y,2);
    isUnique = true(1, numCols);

    % Pairwise comparison with tolerance
    for j = 1:numCols
        if ~isUnique(j)
            continue;
        end
        for k = j+1:numCols
            if isUnique(k) && norm(Y(:,j)-Y(:,k)) < tol
                isUnique(j) = false;
                isUnique(k) = false;
            end
        end
    end

    numUniqueCols = sum(isUnique);
    disp(['Number of numerically unique columns (M=' num2str(M) '): ' num2str(numUniqueCols)]);
    portion = (numUniqueCols / (3^(i-1))) * 100; % Adjust denominator as needed for your variable set size
    result_table = [result_table; M, portion];
end

disp('Summary (M vs. numUniqueCols):');
disp(array2table(result_table, 'VariableNames',{'M','UniqueColumnsOnce'}));

%{
%% M=N
holes_location=[];
a_all=generate_all_as(S,holes_location,N);
circ_h=genrate_all_circh(a_all);
flam=genrate_all_flam(circ_h,1);
Z_all= genrate_all_Z(circ_h,flam);
A=dftmtx(N);
A=A/sqrt(N);
Y=A*Z_all;

%%%for finding number of injective solutions
% Step 1: Find unique columns and their indices
[uniqueCols, ~, ic] = unique(Y', 'rows');

% Step 2: Count how many times each unique column appears
counts = histcounts(ic, 1:max(ic)+1);

% Step 3: Keep only columns that appear exactly once
uniqueOnly = uniqueCols(counts == 1, :)';

% Step 4: Get count of such columns
numUniqueCols = size(uniqueOnly, 2);

disp(['Number of columns appearing exactly once(M=8): ' num2str(numUniqueCols)]);
%% M=N-1
holes_location=[1];
a_all=generate_all_as(S,holes_location,N);
circ_h=genrate_all_circh(a_all);
flam=genrate_all_flam(circ_h,1);
Z_all= genrate_all_Z(circ_h,flam);
A=dftmtx(N);
A=A/sqrt(N);

A(1, :) = [];
Y=A*Z_all;

%%%for finding number of injective solutions
% Step 1: Find unique columns and their indices
[uniqueCols, ~, ic] = unique(Y', 'rows');

% Step 2: Count how many times each unique column appears
counts = histcounts(ic, 1:max(ic)+1);

% Step 3: Keep only columns that appear exactly once
uniqueOnly = uniqueCols(counts == 1, :)';

% Step 4: Get count of such columns
numUniqueCols = size(uniqueOnly, 2);

disp(['Number of columns appearing exactly once(M=7): ' num2str(numUniqueCols)]);
%% M=N-2
holes_location=[3,7];
a_all=generate_all_as(S,holes_location,N);
circ_h=genrate_all_circh(a_all);flam=genrate_all_flam(circ_h,1);
Z_all= genrate_all_Z(circ_h,flam);
A=dftmtx(N);
A=A/sqrt(N);

A([3,7], :) = [];
Y=A*Z_all;

%%%for finding number of injective solutions
% Step 1: Find unique columns and their indices
[uniqueCols, ~, ic] = unique(Y', 'rows');

% Step 2: Count how many times each unique column appears
counts = histcounts(ic, 1:max(ic)+1);

% Step 3: Keep only columns that appear exactly once
uniqueOnly = uniqueCols(counts == 1, :)';

% Step 4: Get count of such columns
numUniqueCols = size(uniqueOnly, 2);

disp(['Number of columns appearing exactly once(M=6): ' num2str(numUniqueCols)]);

%{
N = 8;
A = dftmtx(N);
A = A/sqrt(N);

% Assume Z_all is an N x numvecs matrix containing all test vectors
% Z_all = ... % (Define this according to your problem context)

numComb = nchoosek(N, 2); % 8C2 = 28
combPairs = nchoosek(1:N, 2);

uniqueCounts = zeros(numComb, 1);
max_num_of_coloumns=0;
for i = 1:numComb
    rowsToRemove = combPairs(i,:);
    A_sub = A;
    A_sub(rowsToRemove, :) = []; % remove two rows
    
    Y = A_sub * Z_all;
    
    % Step 1: Find unique columns and their indices
    [uniqueCols, ~, ic] = unique(Y', 'rows');
    % Step 2: Count how many times each unique column appears
    counts = histcounts(ic, 1:max(ic)+1);
    % Step 3: Keep only columns that appear exactly once
    uniqueOnly = uniqueCols(counts == 1, :)';
    % Step 4: Get count of such columns
    numUniqueCols = size(uniqueOnly, 2);
    if max_num_of_coloumns< numUniqueCols
        max_num_of_coloumns= numUniqueCols;
    end
    uniqueCounts(i) = numUniqueCols;
    disp(['Removed rows: [' num2str(rowsToRemove) '], Unique columns (M=6): ' num2str(numUniqueCols)]);
end
%}

%% M=N-3
holes_location=[3,5,7];
a_all=generate_all_as(S,holes_location,N);
circ_h=genrate_all_circh(a_all);flam=genrate_all_flam(circ_h,1);
Z_all= genrate_all_Z(circ_h,flam);
size(Z_all)

A=dftmtx(N);
A=A/sqrt(N);
A([3,5,7], :) = [];
Y=A*Z_all;

%%%for finding number of injective solutions
% Step 1: Find unique columns and their indices
[uniqueCols, ~, ic] = unique(Y', 'rows');

% Step 2: Count how many times each unique column appears
counts = histcounts(ic, 1:max(ic)+1);

% Step 3: Keep only columns that appear exactly once
uniqueOnly = uniqueCols(counts == 1, :)';

% Step 4: Get count of such columns
numUniqueCols = size(uniqueOnly, 2);

disp(['Number of columns appearing exactly once(M=5): ' num2str(numUniqueCols)]);


%% M=N-4
holes_location=[1,3,6,8];
a_all=generate_all_as(S,holes_location,N);
circ_h=genrate_all_circh(a_all);flam=genrate_all_flam(circ_h,1);
Z_all= genrate_all_Z(circ_h,flam);
size(Z_all)

A=dftmtx(N);
A=A/sqrt(N);
A([1,3,6,8], :) = [];
Y=A*Z_all;

%%%for finding number of injective solutions
% Step 1: Find unique columns and their indices
[uniqueCols, ~, ic] = unique(Y', 'rows');

% Step 2: Count how many times each unique column appears
counts = histcounts(ic, 1:max(ic)+1);

% Step 3: Keep only columns that appear exactly once
uniqueOnly = uniqueCols(counts == 1, :)';

% Step 4: Get count of such columns
numUniqueCols = size(uniqueOnly, 2);

disp(['Number of columns appearing exactly once(M=4): ' num2str(numUniqueCols)]);

%% M=N-5
holes_location=[2,4,5,6,8];
a_all=generate_all_as(S,holes_location,N);
circ_h=genrate_all_circh(a_all);flam=genrate_all_flam(circ_h,1);
Z_all= genrate_all_Z(circ_h,flam);
size(Z_all)

A=dftmtx(N);
A=A/sqrt(N);
A([2,4,5,6,8], :) = [];
Y=A*Z_all;

%%%for finding number of injective solutions
% Step 1: Find unique columns and their indices
[uniqueCols, ~, ic] = unique(Y', 'rows');

% Step 2: Count how many times each unique column appears
counts = histcounts(ic, 1:max(ic)+1);

% Step 3: Keep only columns that appear exactly once
uniqueOnly = uniqueCols(counts == 1, :)';

% Step 4: Get count of such columns
numUniqueCols = size(uniqueOnly, 2);

disp(['Number of columns appearing exactly once(M=3): ' num2str(numUniqueCols)]);

%% M=N-6
holes_location=[1,2,4,6,7,8];
a_all=generate_all_as(S,holes_location,N);
circ_h=genrate_all_circh(a_all);flam=genrate_all_flam(circ_h,1);
Z_all= genrate_all_Z(circ_h,flam);
size(Z_all)
A=dftmtx(N);
A=A/sqrt(N);
A([1,2,4,6,7,8], :) = [];
Y=A*Z_all;

%%%for finding number of injective solutions
% Step 1: Find unique columns and their indices
[uniqueCols, ~, ic] = unique(Y', 'rows');

% Step 2: Count how many times each unique column appears
counts = histcounts(ic, 1:max(ic)+1);

% Step 3: Keep only columns that appear exactly once
uniqueOnly = uniqueCols(counts == 1, :)';

% Step 4: Get count of such columns
numUniqueCols = size(uniqueOnly, 2);

disp(['Number of columns appearing exactly once(M=2): ' num2str(numUniqueCols)]);
%% M=N-7
holes_location=[1,2,3,4,6,7,8];
a_all=generate_all_as(S,holes_location,N);
circ_h=genrate_all_circh(a_all);flam=genrate_all_flam(circ_h,1);
Z_all= genrate_all_Z(circ_h,flam);
size(Z_all)
A=dftmtx(N);
A=A/sqrt(N);
A([1,2,3,4,6,7,8], :) = [];
Y=A*Z_all;

%%%for finding number of injective solutions
% Step 1: Find unique columns and their indices
[uniqueCols, ~, ic] = unique(Y', 'rows');

% Step 2: Count how many times each unique column appears
counts = histcounts(ic, 1:max(ic)+1);

% Step 3: Keep only columns that appear exactly once
uniqueOnly = uniqueCols(counts == 1, :)';

% Step 4: Get count of such columns
numUniqueCols = size(uniqueOnly, 2);

disp(['Number of columns appearing exactly once(M=1): ' num2str(numUniqueCols)]);
%{
%%for finding minimum distance between circ_h elemnets for e.g-    h = [0.8  1 -1 0.6 0 0 0 0];
%%shows min distance as 1.090783 which is less than 2*lambda=2
%% h = [2  1 -1 5 0 0 0 0];
%%shows min distance as 3.346791 which is more than 2*lambda=2... showingwe
%%need uniques z's for every circ_h.
minDist=Inf;
for i = 1:size(circ_h,2)
    for j = i+1:size(circ_h,2)
        d = norm(circ_h(:,i) - circ_h(:,j));   % works for complex entries
        if d < minDist
            minDist = d;
            closestCols = [i j];
        end
    end
end

fprintf('Minimum distance = %.6f between columns %d and %d\n', ...
        minDist, closestCols(1), closestCols(2));

%}
%}