% Given data
M = [1 2 3 4 5 6 7 8];
success_rate = [0 21.399 0 65.432 66.667 100 100 100];

% Plot histogram (bar chart)
figure;
bar(M, success_rate, 'FaceColor', [0.2 0.6 0.9], 'EdgeColor', 'k', 'LineWidth', 1.2);
xlabel('M (Number of Holes)', 'FontSize', 12);
ylabel('Success Rate of Injectivity (%)', 'FontSize', 12);
title('Injectivity Success Rate vs M', 'FontSize', 14);
grid on;

% Set axis limits for clarity
xlim([0.5 8.5]);
ylim([0 110]);

% Add data labels on bars
text(M, success_rate + 2, string(round(success_rate,2)), ...
     'HorizontalAlignment','center', 'FontSize',10, 'FontWeight','bold');
