function z_estimate=z_exhaust(S,N ,lambda, f_lam, h,a)
D = dftmtx(N);
D_H = D'/N;
y = D_H * f_lam;

indicator = zero_indicator(a);  % Binary vector with 1 where a is zero
rows_to_select = find(indicator == 1);  % Indices of rows where indicator is 1
A = D_H(rows_to_select, :);  % Extract those rows from D_Hwh


y_partial = y(indicator == 1);

combs = combvec(S, S, S, S, S, S, S, S); % Use for N=8, adjust for other N
combs = combs'; % Each row is a possible a
for idx = 1:size(combs, 1)
    a = combs(idx, :).'; % column vector
    F_a = D*a;
    y = cconv(F_a', h, N);
    y = y';
    circ_a(:,idx)=y;
    y_real = real(y); 
    y_imag = imag(y);
    mod_y_real = y_real - (2*lambda)*floor((y_real+lambda)/(2*lambda));
    mod_y_imag = y_imag - (2*lambda)*floor((y_imag+lambda)/(2*lambda));
    f_lam1 = mod_y_real + 1j*mod_y_imag;
    F_LAM(:,idx)=f_lam1;
end

Z = F_LAM-circ_a;
Z_real = real(Z);
Z_img = imag(Z);
%{
for idx=1:size(Z,2)
    y_est = A*Z(:,idx);
    if all(abs(y_partial- y_est)<1e-10)
        z_estimate=Z(:,idx);
    end
end
%}
error=Inf;
for idx=1:size(Z,2)
    y_est = A*Z(:,idx);
    if ((norm(y_partial- y_est))^2<error)
        error=(norm(y_partial- y_est))^2;
        z_estimate=Z(:,idx);
    end
end
end