function zero_indicator = zero_indicator(a)
    % zero_indicator returns a vector where entries are 1 where a is zero, else 0
    zero_indicator = double(a == 0);
end
